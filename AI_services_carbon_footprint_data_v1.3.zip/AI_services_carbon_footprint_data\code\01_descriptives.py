"""
01  Sample profile, item descriptives and reliability.

Produces the demographic breakdown of the sample, the usage statistics,
the item means and the Cronbach alpha values reported in the paper.
"""

import io
import pandas as pd
from utils import (load_raw, item_column_map, load_items, construct_scores,
                   CONSTRUCTS, cronbach_alpha, write_output)

raw = load_raw()
cols = item_column_map(raw)
buf = io.StringIO()

# ---- Table 1: demographic and usage frequencies ---------------------------
buf.write("TABLE 1  Sample profile (N = %d)\n\n" % len(raw))
demographics = [
    (1, "Gender"), (2, "Age group"), (3, "Education"),
    (5, "City tier"), (7, "AI usage frequency"),
    (10, "AI usage tenure"), (11, "Primary device"),
    (12, "Payment status"), (13, "Monthly AI expenditure"),
]
for n, label in demographics:
    buf.write("%s\n" % label)
    vc = raw[cols[n]].value_counts()
    for cat, cnt in vc.items():
        buf.write("    %-28s %4d  %5.1f%%\n" % (cat, cnt, 100.0 * cnt / len(raw)))
    buf.write("\n")

# usage scenarios (multi-select)
buf.write("AI usage scenarios (multi-select)\n")
scen = raw[cols[8]].astype(str)
for tag, name in [("A.", "Study / research"), ("C.", "Creative writing / content"),
                  ("D.", "Casual conversation"), ("E.", "Information retrieval"),
                  ("F.", "Other")]:
    n = scen.str.contains(tag, regex=False).sum()
    buf.write("    %-28s %4d  %5.1f%%\n" % (name, n, 100.0 * n / len(raw)))
buf.write("\n")

# ---- item means and standard deviations -----------------------------------
items = load_items()
buf.write("ITEM DESCRIPTIVES (five-point scales)\n")
for c, ns in CONSTRUCTS.items():
    buf.write("\n%s\n" % c)
    for n in ns:
        s = items["Q%d" % n]
        buf.write("    Q%-3d mean = %.3f   sd = %.3f\n" % (n, s.mean(), s.std(ddof=1)))
    score = items[["Q%d" % n for n in ns]].mean(axis=1)
    buf.write("    construct mean = %.3f   sd = %.3f   alpha = %.3f\n"
              % (score.mean(), score.std(ddof=1), cronbach_alpha(items[["Q%d" % n for n in ns]])))

# ---- construct means -------------------------------------------------------
scores = construct_scores(items)
buf.write("\nCONSTRUCT SCORES\n")
for c in CONSTRUCTS:
    buf.write("    %s  mean = %.3f  sd = %.3f\n" % (c, scores[c].mean(), scores[c].std(ddof=1)))

write_output("01_descriptives.txt", buf.getvalue())
