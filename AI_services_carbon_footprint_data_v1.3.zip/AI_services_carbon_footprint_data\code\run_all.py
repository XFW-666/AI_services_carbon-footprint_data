"""
Run the complete analysis pipeline.

Usage:
    cd code
    python run_all.py

Outputs are written to ../outputs/.
"""

import runpy
import os

SCRIPTS = [
    "01_descriptives.py",
    "02_measurement_models.py",
    "03_structural_model.py",
    "04_machine_learning.py",
    "05_clustering.py",
    "06_groups_and_disclosure.py",
    "07_robustness.py",
]

here = os.path.dirname(os.path.abspath(__file__))
for name in SCRIPTS:
    print("=" * 60)
    print("running", name)
    runpy.run_path(os.path.join(here, name), run_name="__main__")
print("=" * 60)
print("all analyses complete")
