"""
05  Exploratory segmentation.

k-means silhouette scores for k = 2..6, a Gaussian mixture comparison by BIC,
bootstrap stability of the k = 3 solution and the standardised cluster
profiles.
"""

import io
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from utils import construct_scores, write_output

scores = construct_scores()
Z = StandardScaler().fit_transform(scores.values)
buf = io.StringIO()

buf.write("K-MEANS SILHOUETTE SCORES\n")
for k in range(2, 7):
    km = KMeans(n_clusters=k, n_init=50, random_state=42).fit(Z)
    buf.write("    k = %d  silhouette = %.3f  sizes = %s\n"
              % (k, silhouette_score(Z, km.labels_), np.bincount(km.labels_).tolist()))

buf.write("\nGAUSSIAN MIXTURE (latent profile) BIC / AIC\n")
for k in range(1, 7):
    gm = GaussianMixture(n_components=k, covariance_type="full",
                         n_init=10, random_state=42).fit(Z)
    buf.write("    k = %d  BIC = %.1f  AIC = %.1f  sizes = %s\n"
              % (k, gm.bic(Z), gm.aic(Z), np.bincount(gm.predict(Z)).tolist()))

km3 = KMeans(n_clusters=3, n_init=50, random_state=42).fit(Z)
base = km3.labels_
rng = np.random.default_rng(0)
aris = []
for _ in range(200):
    idx = rng.choice(len(Z), len(Z), replace=True)
    lab = KMeans(n_clusters=3, n_init=10, random_state=1).fit(Z[idx]).labels_
    aris.append(adjusted_rand_score(base[idx], lab))
buf.write("\nBOOTSTRAP STABILITY OF k = 3 (200 resamples)\n")
buf.write("    adjusted Rand index: mean = %.3f  sd = %.3f  min = %.3f\n\n"
          % (np.mean(aris), np.std(aris), np.min(aris)))

profiles = pd.DataFrame(km3.cluster_centers_, columns=scores.columns)
buf.write("STANDARDISED CLUSTER PROFILES (k = 3)\n")
buf.write(profiles.round(2).to_string() + "\n\n")
buf.write("Cluster sizes: %s\n" % np.bincount(base).tolist())

# within-cluster intention-behaviour gap
buf.write("\nINTENTION-BEHAVIOUR GAP BY CLUSTER (raw scale)\n")
for k in range(3):
    sub = scores[base == k]
    buf.write("    cluster %d (n = %3d): intention = %.2f  behaviour = %.2f  gap = %+.2f\n"
              % (k, len(sub), sub["INT"].mean(), sub["BEH"].mean(),
                 sub["INT"].mean() - sub["BEH"].mean()))

write_output("05_clustering.txt", buf.getvalue())
