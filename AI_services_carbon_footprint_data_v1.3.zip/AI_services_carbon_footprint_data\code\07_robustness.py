"""
07  Robustness analyses.

(a) a structural model with demographic controls, (b) a re-specified model
that drops items measuring adjacent constructs, and (c) a seven-factor
exploratory solution used to inspect cross-loadings.
"""

import io
import numpy as np
import pandas as pd
import statsmodels.api as sm
from factor_analyzer import FactorAnalyzer
from semopy import Model
from semopy.stats import calc_stats
from utils import (load_raw, item_column_map, load_items, construct_scores,
                   CONSTRUCTS, write_output)

raw = load_raw()
cols = item_column_map(raw)
items = load_items()
scores = construct_scores(items)
buf = io.StringIO()

# ---- (a) demographic controls ---------------------------------------------
age_map = {"A. 18岁以下": 1, "B. 18-24岁": 2, "C. 25-34岁": 3,
           "D. 35-44岁": 4, "E. 45-54岁": 5, "F. 55岁及以上": 6}
edu_map = {"A. 高中及以下": 1, "B. 大专": 2, "C. 本科": 3, "D. 硕士": 4, "E. 博士": 5}
city_map = {"A. 一线城市": 1, "B. 新一线城市": 2, "C. 二线城市": 3,
            "D. 三线及以下城市/乡镇": 4}
freq_map = {"A. 偶尔（1-2次/周）": 1, "B. 经常（3-6次/周）": 2,
            "C. 频繁（1-2次/天）": 3, "D. 非常频繁（3次以上/天）": 4}
controls = pd.DataFrame({
    "age": raw[cols[2]].map(age_map),
    "education": raw[cols[3]].map(edu_map),
    "city_tier": raw[cols[5]].map(city_map),
    "usage_frequency": raw[cols[7]].map(freq_map),
    "male": (raw[cols[1]] == "A. 男").astype(int),
    "female": (raw[cols[1]] == "B. 女").astype(int),
})
Z = (scores - scores.mean()) / scores.std(ddof=1)
C = (controls - controls.mean()) / controls.std(ddof=1)

buf.write("(a) DEMOGRAPHIC-CONTROL MODELS\n")
for y, xs in [("INT", ["ATT", "SN", "PBC", "AWA", "PTG"]),
              ("BEH", ["INT", "PBC", "SN", "PTG"])]:
    base = sm.OLS(Z[y], sm.add_constant(Z[xs])).fit()
    full = sm.OLS(Z[y], sm.add_constant(pd.concat([Z[xs], C], axis=1))).fit()
    buf.write("\n  %s: R2 without controls = %.3f ; with controls = %.3f\n"
              % (y, base.rsquared, full.rsquared))
    for x in xs:
        buf.write("    %-4s beta = %+.3f (p = %.3g)  ->  %+.3f (p = %.3g)\n"
                  % (x, base.params[x], base.pvalues[x], full.params[x], full.pvalues[x]))

# ---- (b) structural model excluding ambiguous items -----------------------
AMBIGUOUS = {"ATT": [28], "PBC": [34, 35], "SN": [41]}
reduced = {c: [n for n in ns if n not in AMBIGUOUS.get(c, [])]
           for c, ns in CONSTRUCTS.items()}
spec = "\n".join("%s =~ %s" % (c, " + ".join("Q%d" % n for n in ns))
                 for c, ns in reduced.items())
spec += "\nINT ~ ATT + SN + PBC + AWA + PTG\nBEH ~ INT + PBC + SN + PTG\n"
model = Model(spec)
model.fit(items)
st = calc_stats(model).iloc[0]
buf.write("\n\n(b) STRUCTURAL MODEL EXCLUDING 4 ADJACENT-ITEM CONSTRUCTS\n")
buf.write("    fit: chi2 = %.1f  df = %d  CFI = %.3f  TLI = %.3f  RMSEA = %.3f\n"
          % (st["chi2"], st["DoF"], st["CFI"], st["TLI"], st["RMSEA"]))
ins = model.inspect(std_est=True)
paths = ins[(ins["op"] == "~") & (ins["lval"].isin(["INT", "BEH"]))]
for _, r in paths.iterrows():
    buf.write("    %s -> %-4s  beta = %+.3f  p = %.3g\n"
              % (r["rval"], r["lval"], r["Est. Std"], r["p-value"]))

# ---- (c) seven-factor exploratory cross-loadings --------------------------
fa = FactorAnalyzer(n_factors=7, rotation="promax", method="principal")
fa.fit(items)
loadings = pd.DataFrame(fa.loadings_, index=items.columns)
buf.write("\n\n(c) SEVEN-FACTOR EFA: SECONDARY LOADINGS ABOVE 0.30\n")
for item in loadings.index:
    row = loadings.loc[item].sort_values(ascending=False)
    top = row.index[0]
    others = [(f, row[f]) for f in row.index if f != top and abs(row[f]) > 0.30]
    if others:
        buf.write("    %s: primary = %+.2f (factor %s); "
                  % (item, row.iloc[0], top)
                  + ", ".join("factor %s = %+.2f" % (f, v) for f, v in others) + "\n")
buf.write("    (no other item had a secondary loading above 0.30)\n")

write_output("07_robustness.txt", buf.getvalue())
