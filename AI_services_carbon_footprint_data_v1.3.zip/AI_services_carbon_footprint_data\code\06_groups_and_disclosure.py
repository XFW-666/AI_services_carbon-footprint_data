"""
06  Information-disclosure tasks and demographic comparisons.

Reports the answers to the two disclosure tasks, the age-group tests and the
numerical cross-checks for the sample description.
"""

import io
import numpy as np
import pandas as pd
from scipy import stats
from utils import (load_raw, item_column_map, load_items, construct_scores,
                   CONSTRUCTS, cronbach_alpha, write_output)

raw = load_raw()
cols = item_column_map(raw)
items = load_items()
scores = construct_scores(items)
N = len(raw)
buf = io.StringIO()

# ---- numerical cross-checks for the sample description --------------------
buf.write("NUMERICAL CROSS-CHECKS\n")
fee = raw[cols[13]]
over50 = fee.isin(["C. 50-200元", "D. 200元以上"]).sum()
over200 = (fee == "D. 200元以上").sum()
buf.write("    monthly expenditure > 50 yuan : %d (%.1f%%)\n" % (over50, 100 * over50 / N))
buf.write("    monthly expenditure > 200 yuan: %d (%.1f%%)\n" % (over200, 100 * over200 / N))
scen = raw[cols[8]].astype(str)
ret = scen.str.contains("E.", regex=False).sum()
buf.write("    information retrieval scenario : %d (%.1f%%)\n\n" % (ret, 100 * ret / N))

# ---- disclosure tasks ------------------------------------------------------
q45 = raw[cols[45]]
q46 = raw[cols[46]]
buf.write("DISCLOSURE TASK 1: change in willingness to use AI\n")
for cat, cnt in q45.value_counts().items():
    buf.write("    %-16s %4d  %5.1f%%\n" % (cat, cnt, 100 * cnt / N))
buf.write("DISCLOSURE TASK 2: change in attention\n")
for cat, cnt in q46.value_counts().items():
    buf.write("    %-16s %4d  %5.1f%%\n" % (cat, cnt, 100 * cnt / N))
inc = (q46 == "A. 显著提高").sum() + (q46 == "B. 有所提高").sum()
buf.write("    increased attention (A + B) = %d (%.1f%%)\n\n" % (inc, 100 * inc / N))

# ---- demographic comparisons ----------------------------------------------
age = raw[cols[2]]
groups = sorted(age.unique())
buf.write("AGE-GROUP TESTS\n")
buf.write("    group sizes: %s\n" % {g: int((age == g).sum()) for g in groups})
for c in ["AWA", "INT", "BEH"]:
    F, p = stats.f_oneway(*[scores.loc[age == g, c].values for g in groups])
    buf.write("    one-way ANOVA %s: F = %.3f  p = %.3f\n" % (c, F, p))

age_merged = age.map({"A. 18岁以下": "<35", "B. 18-24岁": "<35", "C. 25-34岁": "<35",
                      "D. 35-44岁": "35-44", "E. 45-54岁": "45-54", "F. 55岁及以上": "55+"})
mg = sorted(age_merged.unique())
F, p = stats.f_oneway(*[scores.loc[age_merged == g, "AWA"].values for g in mg])
H, pk = stats.kruskal(*[scores.loc[age_merged == g, "AWA"].values for g in mg])
buf.write("    merged categories (AWA): F = %.3f  p = %.3f | Kruskal H = %.3f  p = %.3f\n"
          % (F, p, H, pk))
buf.write("    AWA mean by merged group:\n")
for g in mg:
    buf.write("        %-6s mean = %.3f  n = %d\n"
              % (g, scores.loc[age_merged == g, "AWA"].mean(), int((age_merged == g).sum())))
buf.write("\n")

# ---- note on the analytic sample -------------------------------------------
buf.write("ANALYTIC SAMPLE: two respondents who reported being under 18 were "
          "excluded under the age-eligibility criterion (age >= 18); N = %d.\n"
          % len(raw))

write_output("06_groups_and_disclosure.txt", buf.getvalue())
