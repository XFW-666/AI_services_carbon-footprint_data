"""
Shared helpers for the AI carbon-footprint survey analysis.

Author: Fangwei Xue
Contact: 4124640088@email.sdfmu.edu.cn

All scripts read the de-identified response file
    data/survey_responses_406.xlsx
and write plain-text outputs to
    outputs/.
"""

import os
import re
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DATA_PATH = os.path.join(ROOT, "data", "survey_responses_406.xlsx")
OUT_DIR = os.path.join(ROOT, "outputs")
os.makedirs(OUT_DIR, exist_ok=True)

# Five-point response labels -> numeric codes
AGREE = {"非常不同意": 1, "不同意": 2, "中立": 3, "同意": 4, "非常同意": 5}
AWARE = {"完全不了解": 1, "不太了解": 2, "一般": 3, "比较了解": 4, "非常了解": 5}
LABELS = {**AGREE, **AWARE}

# Item numbers (as printed in the questionnaire) for each construct
CONSTRUCTS = {
    "AWA": [14, 15, 16, 17, 18, 19],   # awareness of the AI carbon footprint
    "PTG": [20, 21, 22, 23, 24, 25],   # perceived transparency / transparency demand
    "ATT": [26, 27, 28, 29],           # environmental attitude
    "INT": [30, 31, 32, 33],           # sustainable-consumption intention
    "PBC": [34, 35, 36, 37, 38],       # perceived behavioural control
    "SN":  [39, 40, 41],               # subjective norms
    "BEH": [42, 43, 44],               # self-reported sustainable behaviour
}

# The two facets of the transparency construct used in the split analysis
PTG_FACETS = {
    "OPACITY": [20, 21, 24],   # perceived lack of disclosure
    "DEMAND":  [22, 23, 25],   # demand for disclosure
}


def _item_number(column_name):
    """Extract the leading item number from a questionnaire column header."""
    m = re.match(r"^\s*(\d+)\s*[、.．]", str(column_name))
    return int(m.group(1)) if m else None


UNDER18_LABEL = "A. 18岁以下"


def _age_column(df):
    for col in df.columns:
        if re.match(r"^\s*2\s*[、.．]", str(col)):
            return col
    raise KeyError("age column not found")


def load_raw(include_under18=False):
    """Return the response table.

    Two respondents who reported being under 18 are excluded by default
    (age eligibility is 18 or over), giving the N = 404 analytic sample used
    in the paper. Pass include_under18=True to obtain all 406 collected
    responses.
    """
    df = pd.read_excel(DATA_PATH)
    if not include_under18:
        df = df[df[_age_column(df)] != UNDER18_LABEL].reset_index(drop=True)
    return df


def item_column_map(df):
    """Map each questionnaire item number to its column name."""
    mapping = {}
    for col in df.columns:
        n = _item_number(col)
        if n is not None:
            mapping[n] = col
    return mapping


def load_items():
    """Return a numeric item matrix with columns Q14..Q44 (five-point scales)."""
    df = load_raw()
    cols = item_column_map(df)
    data = {}
    for n in range(14, 45):
        data["Q%d" % n] = df[cols[n]].map(LABELS)
    return pd.DataFrame(data)


def construct_scores(items=None):
    """Return mean composite scores for the seven constructs."""
    if items is None:
        items = load_items()
    return pd.DataFrame(
        {c: items[["Q%d" % n for n in ns]].mean(axis=1) for c, ns in CONSTRUCTS.items()}
    )


def cronbach_alpha(frame):
    k = frame.shape[1]
    var_items = frame.var(ddof=1).sum()
    var_total = frame.sum(axis=1).var(ddof=1)
    return k / (k - 1) * (1 - var_items / var_total)


def write_output(name, text):
    path = os.path.join(OUT_DIR, name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    print("wrote outputs/%s" % name)
