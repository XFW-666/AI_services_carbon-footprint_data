# Data and code for the study on carbon footprint awareness of AI services

This package contains the survey data, the questionnaire, and the Python code
used in the manuscript "The invisible carbon footprint of artificial
intelligence services and sustainable consumption behaviour among Chinese
users". The dataset is also archived on Zenodo:
https://doi.org/10.5281/zenodo.23910453

## Contents

    data/          raw responses, CSV copy and data dictionary
    instrument/    questionnaire (Chinese and English) and the two disclosure tasks
    code/          analysis scripts and requirements.txt
    outputs/       plain text output of each script

## Data

The file data/survey_responses_406.xlsx is the raw export of the online
questionnaire and holds 406 responses. Eligibility was set at age 18 or above,
so the two respondents who reported being under 18 were dropped from the
analysis and the results in the paper are based on 404 responses. The code
applies this exclusion automatically.

Respondents were recruited through a commercial online panel and invited by
WeChat between December 2025 and January 2026. The data are de-identified: the
IP column was replaced by a province and city label that was only used for
quality control.

Items Q14 to Q19 measure self-assessed awareness of the carbon footprint of AI
services (1 = completely unaware, 5 = fully aware). Items Q20 to Q44 use
five-point agreement scales (1 = strongly disagree, 5 = strongly agree). Q45
and Q46 record the answers to the two disclosure tasks, Q47 and Q48 are open
questions. data/data_dictionary.csv lists every variable with its Chinese and
English wording, the construct it belongs to and the response labels.

## Code

The scripts were written for Python 3.12.

    cd code
    pip install -r requirements.txt
    python run_all.py

Each script can also be run on its own. All scripts write plain text results
into the outputs folder.

## Ethics

The study was approved by the Science and Technology Ethics Committee, School
of Public Health, Shandong University (STEC-SPH-SDU-20251120, approved on
26 November 2025). All participants gave informed consent before answering.

## License

The data are released under CC BY 4.0 and the code under the MIT license,
see the LICENSE file.

## Contact

Fangwei Xue, 4124640088@email.sdfmu.edu.cn
