"""
04  Machine-learning predictive check.

A random forest predicts sustainable-consumption intention from its five
antecedents and is evaluated with 10-fold cross-validation (seed 42).
Permutation importance is computed on held-out folds.
"""

import io
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import KFold, cross_val_predict
from utils import construct_scores, write_output

scores = construct_scores()
features = ["ATT", "SN", "PBC", "AWA", "PTG"]
X = scores[features].values
y = scores["INT"].values
buf = io.StringIO()

rf = RandomForestRegressor(n_estimators=800, random_state=42)
kf = KFold(n_splits=10, shuffle=True, random_state=42)
pred = cross_val_predict(rf, X, y, cv=kf)
buf.write("RANDOM FOREST: 10-FOLD CROSS-VALIDATION\n")
buf.write("    cross-validated R2  = %.3f\n" % r2_score(y, pred))
buf.write("    cross-validated MAE = %.3f\n" % mean_absolute_error(y, pred))

fold_r2, fold_mae = [], []
for tr, te in kf.split(X):
    rf.fit(X[tr], y[tr])
    p = rf.predict(X[te])
    fold_r2.append(r2_score(y[te], p))
    fold_mae.append(mean_absolute_error(y[te], p))
buf.write("    per-fold R2: mean = %.3f  sd = %.3f  min = %.3f  max = %.3f\n\n"
          % (np.mean(fold_r2), np.std(fold_r2), np.min(fold_r2), np.max(fold_r2)))

rf.fit(X, y)
imp = permutation_importance(rf, X, y, n_repeats=30, random_state=42, scoring="r2")
buf.write("PERMUTATION IMPORTANCE (mean decrease in R2)\n")
for f, m, s in sorted(zip(features, imp.importances_mean, imp.importances_std),
                      key=lambda t: -t[1]):
    buf.write("    %-4s %.3f  (sd %.3f)\n" % (f, m, s))

write_output("04_machine_learning.txt", buf.getvalue())
