# Information-disclosure tasks (exact stimuli)

Both statements were presented to every respondent, in the order shown, with
no randomisation, no control condition and no pre-task measure. The two tasks
are therefore within-subject information-disclosure tasks; the responses are
self-reported reactions and are not experimental or causal effects.

The two figures are illustrative equivalences used to convey an order of
magnitude. They are not life-cycle assessments. In particular, the 500-ml
comparison refers to the carbon emissions associated with producing a bottle
of water and should not be read as a statement about water consumption by AI
systems.

---

## Task 1 (item Q45)

**Chinese (as shown to respondents):**

> 一次典型ChatGPT对话（约10轮）的碳排放约为500ml瓶装水的生产碳排放。了解此信息后，您的AI使用意愿是否发生变化？

**English:**

> A typical ChatGPT conversation (about ten turns) produces approximately the
> same carbon emissions as producing a 500-ml bottle of water. After learning
> this information, has your willingness to use AI changed?

**Response options (single choice):**

| Code | Chinese | English |
|---|---|---|
| A | 会减少使用 | I would reduce my use |
| B | 可能会减少 | I might reduce my use |
| C | 没有变化 | No change |
| D | 反而想多试试 | I would actually like to use it more |

---

## Task 2 (item Q46)

**Chinese (as shown to respondents):**

> 训练GPT-3的碳排放相当于一辆汽车行驶约70万公里。了解此信息后，您对AI碳足迹的关注度？

**English:**

> Training GPT-3 produced carbon emissions equivalent to driving a car about
> 700,000 km. After learning this information, how has your attention to the
> AI carbon footprint changed?

**Response options (single choice):**

| Code | Chinese | English |
|---|---|---|
| A | 显著提高 | Greatly increased |
| B | 有所提高 | Somewhat increased |
| C | 没有变化 | No change |
