"""
02  Measurement models: EFA with parallel analysis, a comparison of
    alternative CFA models, reliability, convergent validity and HTMT.
"""

import io
import itertools
import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer
from semopy import Model
from semopy.stats import calc_stats
from utils import load_items, CONSTRUCTS, cronbach_alpha, write_output

items = load_items()
buf = io.StringIO()
item_names = list(items.columns)

# ---- parallel analysis -----------------------------------------------------
corr = np.corrcoef(items.values, rowvar=False)
eigen = np.linalg.eigvalsh(corr)[::-1]
rng = np.random.default_rng(42)
rand = []
for _ in range(1000):
    r = np.corrcoef(rng.normal(size=items.shape), rowvar=False)
    rand.append(np.linalg.eigvalsh(r)[::-1])
rand = np.array(rand)
p95 = np.percentile(rand, 95, axis=0)
buf.write("PARALLEL ANALYSIS (1000 random datasets)\n")
for i in range(10):
    buf.write("    factor %d  eigenvalue = %.3f   random 95th pct = %.3f\n"
              % (i + 1, eigen[i], p95[i]))
buf.write("    factors with eigenvalue > 1 : %d\n" % int((eigen > 1).sum()))
buf.write("    factors above random 95th pct: %d\n\n"
          % int((eigen > p95).sum()))

# ---- exploratory factor analysis (5 factors, promax) -----------------------
fa = FactorAnalyzer(n_factors=5, rotation="promax", method="principal")
fa.fit(items)
load = pd.DataFrame(fa.loadings_, index=item_names)
buf.write("EFA PATTERN MATRIX (promax, 5 factors)\n")
buf.write(load.round(2).to_string() + "\n\n")

# ---- confirmatory factor analysis: alternative models ----------------------
def build(spec):
    return "\n".join("%s =~ %s" % (c, " + ".join("Q%d" % n for n in ns))
                     for c, ns in spec.items())

def fit(spec, name):
    m = Model(build(spec))
    m.fit(items)
    st = calc_stats(m).iloc[0]
    buf.write("[%s] chi2 = %.1f  df = %d  CFI = %.3f  TLI = %.3f  RMSEA = %.3f  "
              "AIC = %.1f  BIC = %.1f\n"
              % (name, st["chi2"], st["DoF"], st["CFI"], st["TLI"],
                 st["RMSEA"], st["AIC"], st["BIC"]))
    return m

buf.write("CONFIRMATORY MODEL COMPARISON\n")
m7 = fit(CONSTRUCTS, "7-factor (hypothesised)")
merged6 = {c: ns for c, ns in CONSTRUCTS.items() if c not in ("SN", "BEH")}
merged6["SN_BEH"] = CONSTRUCTS["SN"] + CONSTRUCTS["BEH"]
fit(merged6, "6-factor (SN + BEH merged)")
merged5 = {c: ns for c, ns in merged6.items() if c not in ("ATT", "INT")}
merged5["ATT_INT"] = merged6["ATT"] + merged6["INT"]
fit(merged5, "5-factor (SN + BEH, ATT + INT merged)")
fit({"GEN": [n for ns in CONSTRUCTS.values() for n in ns]}, "1-factor")

# ---- reliability and convergent validity from the 7-factor model -----------
ins = m7.inspect(std_est=True)
buf.write("\nRELIABILITY AND CONVERGENT VALIDITY (7-factor model)\n")
for c, ns in CONSTRUCTS.items():
    lam = np.array([abs(ins[(ins["rval"] == c) & (ins["op"] == "~")
                            & (ins["lval"] == "Q%d" % n)]["Est. Std"].values[0]) for n in ns])
    cr = lam.sum() ** 2 / (lam.sum() ** 2 + (1 - lam ** 2).sum())
    ave = (lam ** 2).mean()
    buf.write("    %s  alpha = %.3f  CR = %.3f  AVE = %.3f  min loading = %.3f\n"
              % (c, cronbach_alpha(items[["Q%d" % n for n in ns]]), cr, ave, lam.min()))

# ---- HTMT discriminant validity -------------------------------------------
def htmt():
    names = list(CONSTRUCTS)
    out = pd.DataFrame(np.nan, index=names, columns=names)
    for a, b in itertools.combinations(names, 2):
        het = [abs(items["Q%d" % i].corr(items["Q%d" % j]))
               for i in CONSTRUCTS[a] for j in CONSTRUCTS[b]]
        mono_a = [abs(items["Q%d" % i].corr(items["Q%d" % j]))
                  for i, j in itertools.combinations(CONSTRUCTS[a], 2)]
        mono_b = [abs(items["Q%d" % i].corr(items["Q%d" % j]))
                  for i, j in itertools.combinations(CONSTRUCTS[b], 2)]
        v = np.mean(het) / np.sqrt(np.mean(mono_a) * np.mean(mono_b))
        out.loc[a, b] = out.loc[b, a] = v
    return out

buf.write("\nHTMT RATIO MATRIX (threshold 0.85-0.90)\n")
buf.write(htmt().round(3).to_string() + "\n")

write_output("02_measurement_models.txt", buf.getvalue())
