# Questionnaire (Chinese with English translation)

**Study:** The invisible carbon footprint of artificial intelligence services
and sustainable consumption behaviour among Chinese users

**Instrument:** structured online questionnaire, four blocks, 48 items.
Administered in Chinese. Items Q14–Q19 use a five-point awareness scale
(1 = completely unaware, 5 = fully aware). Items Q20–Q44 use a five-point
agreement scale (1 = strongly disagree, 5 = strongly agree).

---

## Block 1. Demographics and AI-use profile

**Q1. 您的性别 / Your gender**
A. 男 (male) · B. 女 (female) · C. 不愿透露 (prefer not to say)

**Q2. 您的年龄段 / Your age group**
A. 18岁以下 (under 18) · B. 18–24岁 · C. 25–34岁 · D. 35–44岁 · E. 45–54岁 · F. 55岁及以上 (55+)

**Q3. 您的最高学历 / Your highest education level**
A. 高中及以下 (high school or below) · B. 大专 (junior college) · C. 本科 (bachelor) · D. 硕士 (master) · E. 博士 (doctorate)

**Q4. 您的专业/职业背景 / Your field of study or occupational background**
A. 理工科/技术类 · B. 人文社科类 · C. 经管类 · D. 医学/农学类 · E. 其他

**Q5. 您目前居住的地区 / Your region of residence**
A. 一线城市 (tier-1) · B. 新一线城市 (new tier-1) · C. 二线城市 (tier-2) · D. 三线及以下城市/乡镇 (tier-3 or below)

**Q6. 您是否使用过AI大语言模型服务（如ChatGPT、文心一言、通义千问、DeepSeek等）？ / Have you used an AI large-language-model service (ChatGPT, Wenxin Yiyan, Tongyi Qianwen, DeepSeek, etc.)?**
A. 是 (yes) · B. 否 (no)

**Q7. 您平均每周使用AI服务的频率是？ / How often do you use AI services per week?**
A. 偶尔（1–2次/周） · B. 经常（3–6次/周） · C. 频繁（1–2次/天） · D. 非常频繁（3次以上/天）

**Q8. 您主要将AI服务用于哪些场景？ / What do you mainly use AI services for? (multi-select)**
A. 学习/研究 · B. 编程/技术开发 · C. 创意写作/内容生成 · D. 日常闲聊 · E. 信息检索 · F. 其他

**Q9. 您每次使用时，平均输入/输出的长度大约是？ / Typical length of your input/output per use**
A. 简短（几句话） · B. 中等（几段话） · C. 较长（一篇文章） · D. 非常长（多轮深度对话）

**Q10. 您使用AI服务多长时间了？ / How long have you been using AI services?**
A. 少于1个月 · B. 1–6个月 · C. 6–12个月 · D. 1–2年 · E. 2年以上

**Q11. 您最常通过什么设备使用AI服务？ / Which device do you most often use?**
A. 手机 · B. 电脑 · C. 平板 · D. 其他

**Q12. 您是否付费使用过AI服务？ / Have you ever paid for AI services?**
A. 是，正在订阅 · B. 曾经付费过 · C. 从未付费

**Q13. 您平均每月的AI服务使用费用约为？ / Average monthly spending on AI services**
A. 免费 · B. 50元以下 · C. 50–200元 · D. 200元以上

---

## Block 2. Awareness of the AI carbon footprint (Q14–Q19)
Scale: 1 = 完全不了解 (completely unaware) … 5 = 非常了解 (fully aware)

**Q14.** 我了解AI大模型训练过程需要消耗大量电力。
*I understand that training large AI models consumes a lot of electricity.*

**Q15.** 我了解每次使用AI服务（如提问一次）也会产生碳排放。
*I understand that each use of an AI service (e.g., one query) also produces carbon emissions.*

**Q16.** 我知道"token"（令牌）是AI服务计费和能耗的基本单位。
*I know that the token is the basic unit of billing and energy consumption for AI services.*

**Q17.** 我了解不同AI模型（如GPT-4 vs 轻量模型）的能耗差异。
*I understand the energy-consumption differences between AI models (e.g., GPT-4 vs. lightweight models).*

**Q18.** 我了解AI数据中心的水资源消耗问题。
*I understand the water-resource consumption of AI data centres.*

**Q19.** 我了解AI服务的碳足迹与传统互联网服务（如搜索、邮件）的差异。
*I understand how the carbon footprint of AI services differs from conventional internet services (search, e-mail).*

---

## Block 3. Perceived information gaps, attitudes, norms, control, intention and behaviour (Q20–Q44)
Scale: 1 = 非常不同意 (strongly disagree) … 5 = 非常同意 (strongly agree)

### Perceived transparency / information gap (Q20–Q25)
**Q20.** 我很少在媒体报道中看到关于AI碳足迹的信息。
*I rarely see information about the AI carbon footprint in media coverage.*
**Q21.** AI服务提供商（如OpenAI、百度等）没有充分披露其碳排放信息。
*AI service providers do not adequately disclose their carbon-emission information.*
**Q22.** 我希望在使用AI服务时能看到实时的能耗/碳排放提示。
*I would like to see real-time energy / carbon-emission prompts when using AI services.*
**Q23.** 如果AI界面显示"本次对话产生约X克CO₂"，我会感到惊讶。
*I would be surprised if the AI interface displayed "this conversation produces about X grams of CO2".*
**Q24.** 我认为当前公众对AI环境影响的认知存在严重不足。
*I think public awareness of AI's environmental impact is seriously deficient.*
**Q25.** 我希望了解更多关于AI碳足迹的知识。
*I want to learn more about the AI carbon footprint.*

### Environmental attitude (Q26–Q29)
**Q26.** 我认为气候变化是当今世界面临的严重问题。
*I think climate change is a serious problem facing the world today.*
**Q27.** 我平时关注自己的碳足迹（如节约用电、绿色出行等）。
*I usually pay attention to my own carbon footprint (saving electricity, green travel, etc.).*
**Q28.** 我愿意为减少环境影响而改变自己的行为习惯。
*I am willing to change my habits to reduce environmental impact.*
**Q29.** 我认为数字技术的环境影响也应该被重视。
*I think the environmental impact of digital technology should also be taken seriously.*

### Sustainable-consumption intention (Q30–Q33)
**Q30.** 我愿意为更环保的AI服务支付一定溢价。
*I am willing to pay a premium for more environmentally friendly AI services.*
**Q31.** 了解AI碳足迹后，我愿意减少不必要的AI使用。
*After learning about the AI carbon footprint, I am willing to reduce unnecessary AI use.*
**Q32.** 我会尽量精简提示词（prompt），避免冗长输入。
*I try to keep my prompts concise and avoid lengthy inputs.*
**Q33.** 当有轻量模型可选时，我会优先选择能耗更低的模型。
*When a lightweight model is available, I prefer the model with lower energy consumption.*

### Perceived behavioural control (Q34–Q38)
**Q34.** 我愿意向他人传播关于AI碳足迹的知识。
*I am willing to spread knowledge about the AI carbon footprint to others.*
**Q35.** 我认为AI服务商应该提供"环保模式"（低能耗模式）选项。
*I think AI providers should offer an "eco mode" (low-energy mode) option.*
**Q36.** 我认为我有能力控制自己的AI使用频率。
*I think I am able to control my own frequency of AI use.*
**Q37.** 我知道如何优化提示词以降低token消耗。
*I know how to optimise prompts to reduce token consumption.*
**Q38.** 如果有碳排放提示，我能据此调整使用行为。
*If there were carbon-emission prompts, I could adjust my usage behaviour accordingly.*

### Subjective norms (Q39–Q41)
**Q39.** 我认为关注AI碳足迹是社会责任感的体现。
*I think caring about the AI carbon footprint reflects a sense of social responsibility.*
**Q40.** 如果身边人都在关注AI能耗，我也会更加重视。
*If the people around me were concerned about AI energy use, I would care more too.*
**Q41.** 我认为社会应该倡导"可持续AI使用"的理念。
*I think society should promote the idea of "sustainable AI use".*

### Self-reported sustainable behaviour (Q42–Q44)
**Q42.** 我在使用AI时会刻意精简问题，减少不必要的对话。
*I deliberately keep my questions concise and reduce unnecessary dialogue when using AI.*
**Q43.** 我会避免使用AI处理可以自行解决的问题。
*I avoid using AI for problems I can solve myself.*
**Q44.** 我在选择AI服务时会考虑其环保表现。
*I consider environmental performance when choosing AI services.*

---

## Block 4. Information-disclosure tasks and open-ended items (Q45–Q48)

See `disclosure_stimuli.md` for the exact wording of Q45 and Q46.

**Q47 (open).** 您认为AI服务商应该如何向用户披露碳排放信息？
*How should AI providers disclose carbon-emission information to users?*

**Q48 (open).** 关于AI碳足迹，您最想了解什么？
*What do you most want to know about the AI carbon footprint?*
