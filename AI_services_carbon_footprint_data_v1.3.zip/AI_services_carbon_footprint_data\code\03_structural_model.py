"""
03  Structural model.

Latent covariance-based SEM, the split of the transparency construct into its
two facets, collinearity diagnostics (VIF) and Mardia's normality test.
"""

import io
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from semopy import Model
from semopy.stats import calc_stats
from statsmodels.stats.outliers_influence import variance_inflation_factor
from utils import load_items, construct_scores, CONSTRUCTS, PTG_FACETS, write_output

items = load_items()
scores = construct_scores(items)
buf = io.StringIO()

# ---- Mardia multivariate normality ----------------------------------------
def mardia(X):
    X = np.asarray(X, float)
    n, p = X.shape
    Xc = X - X.mean(0)
    Si = np.linalg.inv(np.cov(Xc, rowvar=False))
    G = Xc @ Si @ Xc.T
    b1 = (G ** 3).sum() / n ** 2
    b2 = np.trace(G @ G) / n
    df = p * (p + 1) * (p + 2) / 6
    chi = n * b1 / 6
    z = (b2 - p * (p + 2)) / np.sqrt(8 * p * (p + 2) / n)
    return chi, df, 1 - stats.chi2.cdf(chi, df), z, 2 * (1 - stats.norm.cdf(abs(z)))

chi, df, p_skew, z, p_kurt = mardia(items.values)
buf.write("MARDIA MULTIVARIATE NORMALITY (31 items)\n")
buf.write("    skewness  chi2 = %.1f  df = %.0f  p = %.3g\n" % (chi, df, p_skew))
buf.write("    kurtosis  z    = %.2f  p = %.3g\n\n" % (z, p_kurt))

# ---- collinearity (VIF) ----------------------------------------------------
X = sm.add_constant(scores.values)
vif = pd.Series([variance_inflation_factor(X, i) for i in range(1, X.shape[1])],
                index=scores.columns)
buf.write("VARIANCE INFLATION FACTORS (construct scores)\n")
buf.write(vif.round(2).to_string() + "\n\n")

# ---- latent covariance-based SEM ------------------------------------------
spec = "\n".join("%s =~ %s" % (c, " + ".join("Q%d" % n for n in ns))
                 for c, ns in CONSTRUCTS.items())
spec += "\nINT ~ ATT + SN + PBC + AWA + PTG\nBEH ~ INT + PBC + SN + PTG\n"
model = Model(spec)
model.fit(items)
st = calc_stats(model).iloc[0]
buf.write("LATENT CB-SEM\n")
buf.write("    chi2 = %.1f  df = %d  CFI = %.3f  TLI = %.3f  RMSEA = %.3f\n\n"
          % (st["chi2"], st["DoF"], st["CFI"], st["TLI"], st["RMSEA"]))
ins = model.inspect(std_est=True)
paths = ins[(ins["op"] == "~") & (ins["lval"].isin(["INT", "BEH"]))][
    ["lval", "rval", "Est. Std", "p-value"]]
buf.write("    structural paths (standardised):\n")
for _, r in paths.iterrows():
    buf.write("        %s -> %-4s  beta = %+.3f  p = %.3g\n"
              % (r["rval"], r["lval"], r["Est. Std"], r["p-value"]))
buf.write("\n")

# ---- composite path models (for reference) --------------------------------
Z = (scores - scores.mean()) / scores.std(ddof=1)

def ols(y, xs, title):
    res = sm.OLS(Z[y], sm.add_constant(Z[xs])).fit()
    buf.write("%s  R2 = %.3f\n" % (title, res.rsquared))
    for x in xs:
        buf.write("    %-4s beta = %+.3f  p = %.3g\n" % (x, res.params[x], res.pvalues[x]))
    buf.write("\n")

buf.write("COMPOSITE PATH MODELS (item-mean scores)\n")
ols("INT", ["ATT", "SN", "PBC", "AWA", "PTG"], "INT ~ predictors")
ols("BEH", ["INT", "PBC", "SN", "PTG"], "BEH ~ predictors")

# ---- transparency facets ---------------------------------------------------
facets = pd.DataFrame({k: items[["Q%d" % n for n in ns]].mean(axis=1)
                       for k, ns in PTG_FACETS.items()})
buf.write("TRANSPARENCY FACETS\n")
buf.write("    correlation(opacity, demand) = %.3f\n" % facets["OPACITY"].corr(facets["DEMAND"]))
Zf = (facets - facets.mean()) / facets.std(ddof=1)
res = sm.OLS(Z["INT"], sm.add_constant(pd.concat([Z[["ATT", "SN", "PBC", "AWA"]], Zf], axis=1))).fit()
buf.write("    INT ~ ATT + SN + PBC + AWA + OPACITY + DEMAND   R2 = %.3f\n" % res.rsquared)
for x in ["OPACITY", "DEMAND"]:
    buf.write("        %-8s beta = %+.3f  p = %.3g\n" % (x, res.params[x], res.pvalues[x]))

write_output("03_structural_model.txt", buf.getvalue())
